
package dsproj;

import java.time.LocalDate;
public class Admin {

    static public final String username = "Admin";
    static public final String password = "Admin";




    public static void adminMenu(){
        while(true){
             
            System.out.println("--- Admin Menu ---");
            System.out.println("1 - Add New Book . ");
            System.out.println("2 - Sort All Books . ");
            System.out.println("3 - Delete Current Book . ");
            System.out.println("0 - Exit .");
            System.out.print("What Would You Like To Do ? : ");
            int choice = Main.scanner.nextInt() ;
             
            switch(choice){
                case 1 :
                    addNewBook();
                    break;
                case 2 :
                    sortAllBooks();
                    break;
                case 3 :
                    deleteBook();
                    break;
                case 0 :
                    System.out.println("Exiting Admin Menu");
                    break ;
                default :
                    System.out.println("Invalid Choice");
                    System.out.println("Please Try Again");
            }
            if (choice == 0) break;
        }
    }

    private static void addNewBook(){
        System.out.print("Please Enter Book Name : ");
        String bookName = Main.scanner.nextLine();
        System.out.print("Please Enter Book Author : ");
        String bookAuthor = Main.scanner.nextLine();
        System.out.print("Please Enter Book Publisher Date(yyyy-mm-dd) : ");
        String publisherDate = Main.scanner.nextLine();
        LocalDate date = LocalDate.parse(publisherDate);
        addBook(bookName, bookAuthor, date);

    }

    private static void addBook(String bookName, String bookAuthor, LocalDate publisherDate){
        Book book = new Book(bookName, bookAuthor, publisherDate);
        Main.booksList.insert(book);
    }

    static private void deleteBook(){
        for(int i = 0; i < Main.booksList.size(); i++){
            Main.booksList.show(i);
        }
        System.out.print("\nWhich Element Would You Like To Delete ? ( -1 Tp Exit ) : ");
        int index = Main.scanner.nextInt();
        if(index != -1){
            if(index == 0){
                Main.booksList.deleteFirst();
            } else if (0 < index && index < Main.booksList.size() -2 ){
                Main.booksList.delete(index - 1);
            } else if (index == Main.booksList.size() -1){
                Main.booksList.deleteLast();
            } else {
                System.out.println("Invalid Index");
                System.out.println("Please Try Again");
            }
        }


    }


    static private void sortAllBooks(){
        Main.booksList.sort();
    }


}
