
package dsproj;
import java.util.*;
import java.time.LocalDate;

public class Main {

    public static Scanner scanner = new Scanner(System.in) ; 
    public static LinkedList booksList = new LinkedList() ;

    public static void main(String [] args){


        booksList.insert(new Book("In Search of Lost Time" , "Marcel Proust", LocalDate.parse("1989-09-21")));
        booksList.insert(new Book("Ulysses" , "James Joyce", LocalDate.parse("2001-01-20")));
        booksList.insert(new Book("Don Quixote" , "Miguel de Cervantes", LocalDate.parse("1909-12-01")));
        booksList.insert(new Book("One Hundred Years of Solitude" , "Gabriel Garcia Marquez", LocalDate.parse("2005-01-16")));

        Sys.mainMenu();
    }
}
