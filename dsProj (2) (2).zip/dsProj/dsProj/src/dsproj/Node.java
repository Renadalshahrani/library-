
package dsproj;

public class Node {

    Book data;
    Node next;

    Node(Book data) {
        this.data = data;
    }

}
