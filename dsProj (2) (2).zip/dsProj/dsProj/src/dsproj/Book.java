
package dsproj;


import java.time.LocalDate;
public class Book {
    String name;
    String author ; 
    LocalDate publisherDate;
    Book(String name, String author, LocalDate publisherDate){
        this.name = name;
        this.author = author;
        this.publisherDate = publisherDate;
    }
}
