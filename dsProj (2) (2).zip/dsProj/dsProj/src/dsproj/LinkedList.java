
package dsproj;

import java.time.LocalDate;
class LinkedList {

    Node head;

    public void insert(Book data) {

        Node node = new Node(data);
        node.next = null;

        if (head == null) {
            this.head = node;
        } else {
            Node n = head;
            while (n.next != null) {
                n = n.next;
            }
            n.next = node;
        }

    }

    // return size
    public int size() {
        int size = 0;
        Node n = head;
        while (n != null) {
            size++;
            n = n.next;
        }
        return size;
    }

    // show book with index
    public void show(int index) {
        Node n = head;
        int i = 0;
        while (n != null) {
            if (i == index) {
                System.out.println("Index : " + i +" --> Book Name : " + n.data.name + " | Author : " + n.data.author);
        }
            i++;
            n = n.next;
        }
    }

    public void show() {

        Node node = head;
        while (node.next != null) {
            System.out.println("Book Name : " + node.data.name + " | Author : " + node.data.author);
            node = node.next;
        }
        System.out.println("Book Name : " + node.data.name + " | Author : " + node.data.author);

    }

    // sort the linked list by book name
    public void sort() {
        Node node = head;
        Node temp = null;
        while (node.next != null) {
            temp = node.next;
            while (temp != null) {
                if (node.data.name.compareTo(temp.data.name) > 0) {
                    Book tempData = node.data;
                    node.data = temp.data;
                    temp.data = tempData;
                }
                temp = temp.next;
            }
            node = node.next;
        }
    }

    public void searchByName(String name) {
        Node node = head;
        while (node != null) {
            if (node.data.name.equals(name)) {
                System.out.println("Found : " + node.data.name + " | Author : " + node.data.author + " | Publisher Date : " + node.data.publisherDate);
                return;
            }
            node = node.next;
        }
        System.out.println("Not Could Not Found Book : " + name);
    }
    public void searchByAuthor(String author) {
        Node node = head;
        while (node != null) {
            if (node.data.author.equals(author)) {
                System.out.println("Found : " + node.data.name + " | Author : " + node.data.author + " | Publisher Date : " + node.data.publisherDate);
                return;
            }
            node = node.next;
        }
        System.out.println("Not Could Not Found Book of : " + author);
    }
    public void searchByPublisherDate(LocalDate date) {
        Node node = head;
        while (node != null) {
            if (node.data.publisherDate.equals(date)) {
                System.out.println("Found : " + node.data.name + " | Author : " + node.data.author + " | Publisher Date : " + node.data.publisherDate);
                return;
            }
            node = node.next;
        }
        System.out.println("Not Could Not Found Book with Publisher Date: " + date);
    }

    public void deleteAll() {
        head = null;
    }

    public void delete(String name) {
        Node node = head;
        Node temp = null;
        while (node.next != null) {
            if (node.data.name.equals(name)) {
                temp = node.next;
                node.next = temp.next;
                return;
            }
            node = node.next;
        }
        System.out.println("Not Found Book : " + name);
    }

    // delete by index
    public void delete(int index) {
        Node node = head;
        Node temp = null;
        int i = 0;
        while (node.next != null) {
            if (i == index) {
                temp = node.next;
                node.next = temp.next;
                return;
            }
            node = node.next;
            i++;
        }
        System.out.println("Not Found Book : " + index);
    }

    // delete first node
    public void deleteFirst() {
        head = head.next;
    }

    // delete last node
    public void deleteLast() {
        Node node = head;
        Node temp = null;
        while (node.next != null) {
            temp = node;
            node = node.next;
        }
        temp.next = null;
    }

}



