
package dsproj;

import java.time.LocalDate;
public class User {

    public static void searchMenu() {
        System.out.println("Enter one of the following option: ");
        System.out.println("1. Search A Book by it's Name .");
        System.out.println("2. Search A Book by it's Author .");
        System.out.println("3. Search A Book by it's Publisher Date .");
        int choice = Main.scanner.nextInt();
        Main.scanner.skip("\\R?");
        switch(choice){
            case 1:
                searchByName();
                break;
            case 2:
                searchByAuthor();
                break;
            case 3:
                searchByPublisherDate();
                break;
        }
    }


    public static void searchByName() {
        System.out.print("Please Enter Book Name : ");
        String bookName = Main.scanner.nextLine() ;
        Main.booksList.searchByName(bookName);
        pauseMenu() ;
    }
    public static void searchByAuthor() {
        System.out.print("Please Enter Book Author : ");
        String author = Main.scanner.nextLine() ;
        Main.booksList.searchByAuthor(author);
        pauseMenu() ;
    }
    public static void searchByPublisherDate() {
        System.out.print("Please Enter Publisher Date(yyyy-mm-dd) : ");
        String date = Main.scanner.next() ;
        Main.booksList.searchByPublisherDate(LocalDate.parse(date));
        pauseMenu() ;
    }

    public static void displayAllBooks() {
        Main.booksList.sort();
        Main.booksList.show();
        pauseMenu();
    }

    public static void pauseMenu(){
        System.out.print("Press any key to continue...  ");
        
        Main.scanner.nextLine();
    }


}
