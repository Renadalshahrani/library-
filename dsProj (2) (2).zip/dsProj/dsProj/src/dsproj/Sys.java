
package dsproj;


public class Sys {
    

    public static void mainMenu(){

        while(true){

            System.out.println("--------   Welcome To Our Library  -------");
             System.out.println("");
            System.out.println(" Services :");
             System.out.println("");
            System.out.println("1 - Look For A Book . ");
            System.out.println("2 - Display All Books .");
            System.out.println("0 - Exit ");
            System.out.println("9 - if you are admin  ");
             System.out.println("");
            System.out.print("What Would You Like To Do ? : ");
            int choice = Main.scanner.nextInt();
            

            switch (choice) {
                case 1 :
                    User.searchMenu();
                    break ;
                case 2 :
                    User.displayAllBooks();
                    break ;
                case 9 :
                    System.out.print("Please Enter Admin Username : ");
                    String username = Main.scanner.next();
                    System.out.print("Please Enter Admin Password : ");
                    String password = Main.scanner.next();
                    if(username.equalsIgnoreCase(Admin.username) && password.equalsIgnoreCase(Admin.password)){
                        Admin.adminMenu();
                    }
                    break ;
                case 0 :
                    break ;
                default :
                    System.out.println("Wrong Input ! Please Try Again .");
                    break ;
            }
            if(choice == 0) {
                System.out.println("Thank You For Using Our Library");
                break ;
            }
        }


    }

 


}
